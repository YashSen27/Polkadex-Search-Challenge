import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <img src="https://weftse.csb.app/logo.png" alt="logo" className="a" />
      <img src="https://weftse.csb.app/text.png" alt="logo" className="b" />
      <img src="https://weftse.csb.app/search.png" alt="logo" className="c" />
    </div>
  );
}
